#include "asap.h"
#include "ui_asap.h"
#include "mainwindow.h"
ASAP::ASAP(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ASAP)
{
    ui->setupUi(this);
}

ASAP::~ASAP()
{
    delete ui;
}

void ASAP::on_ASAP_2_clicked()
{
    ASAP ASAP;
    ASAP.setModal(true);
    ASAP.exec();
}


