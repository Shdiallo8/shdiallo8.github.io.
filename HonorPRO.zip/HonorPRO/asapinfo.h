#ifndef ASAPINFO_H
#define ASAPINFO_H
#include"registrar.h"

#include <QDialog>

namespace Ui {
class ASAPINFO;
}

class ASAPINFO : public QDialog
{
    Q_OBJECT

public:
    explicit ASAPINFO(QWidget *parent = nullptr);
    ~ASAPINFO();

private:
    Ui::ASAPINFO *ui;
};

#endif // ASAPINFO_H
