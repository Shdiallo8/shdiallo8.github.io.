
#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include"menu.h"
#include "asapinfo.h"
#include "registrar.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}





void MainWindow::on_pushButton_Login_clicked()
{
    QString Email =ui->lineEdit_Email->text();
   QString ID =ui->lineEdit_ID->text();
   if(Email=="test" && ID=="test")
    {
        QMessageBox::information(this, "Login","Email and ID is correct");
        hide();
        MENU menu;
        menu.setModal(true);
        menu.exec();

   }
    else
    {
        QMessageBox::warning(this, "Login","Email and ID is not correct");
    }
}

