#include "menu.h"
#include "ui_menu.h"
#include <QMessageBox>
#include "mainwindow.h"
MENU::MENU(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MENU)
{
    ui->setupUi(this);
}

MENU::~MENU()
{
    delete ui;
}



//void MENU::on_pushButton_ASAP_clicked()
//{    hide();
//    QMessageBox::information(this, "ASAP","welcome to ASAP BMCC ,TEL:2212201397, address:70 Murray st,New York,10007-14 Floor,email:asap@bmcc.cuny.edu,for more info visite:");


//    MENU menu;
//    menu.setModal(true);
//    menu.exec();


//    //ASAPINFO asapinfo;

//    // asapinfo.setModal(true);
//    //asapinfo.exec();
//}



//void MENU::on_pushButton_REGISTRAR_clicked()
//{ hide();
//    QMessageBox::information(this, "REGISTRAR", "Welcome to bmcc Registrar, Tel: (212) 220-1290 FAX: (212) 220-1254,EMAIL: registrar@bmcc.cuny.edu,#Adress:Panther Station199 Chambers St. NY, NY 10007, Room S-225");

//    MENU menu;
//    menu.setModal(true);
//    menu.exec();

//    //REGISTRAR registrar;
//    //registrar.setModal(true);
//    //registrar.exec();
//}


//void MENU::on_pushButton_LIBRARY_clicked()
//{ hide();
//    QMessageBox::information(this, "LIBRARY", "Welcome to bmcc Library, Tel: (212) 220-8139 EMAIL: librarary@bmcc.cuny.edu,#Adress:199 Chambers St, Room S410 and S430. NY, NY 10007,");

//    MENU menu;
//    menu.setModal(true);
//    menu.exec();
//}



//void MENU::on_pushButton_ENGLISH_clicked()
//{   hide();
//    QMessageBox::information(this, "ENGLISH", "Welcome to bmcc ENGLISH, Tel:(212) 220-1422; Email:belknap@bmcc.cuny.edu; Adress:199 Chambers St; Room:Room S-510J");
//    MENU menu;
//    menu.setModal(true);
//    menu.exec();
//}




//void MENU::on_pushButton_MOREINFO_clicked()
//{  hide();
//    REGISTRAR registrar;
//    registrar.setModal(true);
//    registrar.exec();
//}


void MENU::on_pushButton_ASAP_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void MENU::on_pushButton_ASAP_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void MENU::on_pushButton_ENGLISH_6_clicked()
{
   ui->stackedWidget->setCurrentIndex(3);
}


void MENU::on_pushButton_ASAP_4_clicked()
{
      ui->stackedWidget->setCurrentIndex(1);
}


void MENU::on_pushButton_REGISTRAR_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}


void MENU::on_pushButton_LIBRARY_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MENU::on_pushButton_ASAP_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void MENU::on_pushButton_ENGLISH_2_clicked()
{
   ui->stackedWidget->setCurrentIndex(3);
}


void MENU::on_pushButton_REGISTRAR_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}


void MENU::on_pushButton_LIBRARY_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MENU::on_pushButton_REGISTRAR_4_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}


void MENU::on_pushButton_LIBRARY_4_clicked()
{
     ui->stackedWidget->setCurrentIndex(2);
}


void MENU::on_pushButton_ENGLISH_4_clicked()
{
     ui->stackedWidget->setCurrentIndex(3);
}


void MENU::on_pushButton_LIBRARY_3_clicked()
{
     ui->stackedWidget->setCurrentIndex(2);
}


void MENU::on_pushButton_ENGLISH_3_clicked()
{
     ui->stackedWidget->setCurrentIndex(3);
}


void MENU::on_pushButton_REGISTRAR_3_clicked()
{
     ui->stackedWidget->setCurrentIndex(4);
}


void MENU::on_pushButton_ASAP_5_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}


void MENU::on_pushButton_ENGLISH_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}


void MENU::on_pushButton_LIBRARY_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MENU::on_pushButton_REGISTRAR_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}

