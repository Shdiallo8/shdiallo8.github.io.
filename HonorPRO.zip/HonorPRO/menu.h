#ifndef MENU_H
#define MENU_H
#include"asapinfo.h"
#include "registrar.h"
#include <QDialog>
#include "mainwindow.h"
namespace Ui {
class MENU;
}

class MENU : public QDialog
{
    Q_OBJECT

public:
    explicit MENU(QWidget *parent = nullptr);
    ~MENU();

private slots:


//    void on_pushButton_ASAP_clicked();



//    void on_pushButton_REGISTRAR_clicked();

//    void on_pushButton_LIBRARY_clicked();

//    void on_pushButton_ENGLISH_clicked();



//    void on_pushButton_logoff_clicked();

// void on_pushButton_clicked();

//    void on_pushButton_MOREINFO_clicked();

  void on_pushButton_ASAP_3_clicked();

    void on_pushButton_ASAP_6_clicked();

  void on_pushButton_ENGLISH_6_clicked();

    void on_pushButton_ASAP_4_clicked();

  void on_pushButton_REGISTRAR_6_clicked();

    void on_pushButton_LIBRARY_6_clicked();

  void on_pushButton_ASAP_2_clicked();

    void on_pushButton_ENGLISH_2_clicked();

  void on_pushButton_REGISTRAR_2_clicked();

    void on_pushButton_LIBRARY_2_clicked();

  void on_pushButton_REGISTRAR_4_clicked();

    void on_pushButton_LIBRARY_4_clicked();

  void on_pushButton_ENGLISH_4_clicked();

    void on_pushButton_LIBRARY_3_clicked();

  void on_pushButton_ENGLISH_3_clicked();

    void on_pushButton_REGISTRAR_3_clicked();

  void on_pushButton_ASAP_5_clicked();

    void on_pushButton_ENGLISH_5_clicked();

  void on_pushButton_LIBRARY_5_clicked();

    void on_pushButton_REGISTRAR_5_clicked();

private:
    Ui::MENU *ui;
    //ASAPINFO *asapinfo;

   // REGISTRAR*registrar;

    QWindow *s;
};

#endif // MENU_H
