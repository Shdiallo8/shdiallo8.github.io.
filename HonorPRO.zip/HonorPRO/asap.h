#ifndef ASAP_H
#define ASAP_H

#include <QDialog>

namespace Ui {
class ASAP;
}

class ASAP : public QDialog
{
    Q_OBJECT

public:
    explicit ASAP(QWidget *parent = nullptr);
    ~ASAP();

private slots:
    void on_ASAP_2_clicked();

private:
    Ui::ASAP *ui;
};

#endif // ASAP_H
