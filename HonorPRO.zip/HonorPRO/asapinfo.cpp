#include "asapinfo.h"
#include "ui_asapinfo.h"

ASAPINFO::ASAPINFO(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ASAPINFO)
{
    ui->setupUi(this);
}

ASAPINFO::~ASAPINFO()
{
    delete ui;
}
