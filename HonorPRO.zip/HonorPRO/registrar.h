#ifndef REGISTRAR_H
#define REGISTRAR_H
#include"menu.h"

#include <QDialog>

namespace Ui {
class REGISTRAR;
}

class REGISTRAR : public QDialog
{
    Q_OBJECT

public:
    explicit REGISTRAR(QWidget *parent = nullptr);
    ~REGISTRAR();

private slots:

    void on_pushButton_menu_clicked();

private:
    Ui::REGISTRAR *ui;
};

#endif // REGISTRAR_H
