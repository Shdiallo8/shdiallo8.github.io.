#include "registrar.h"
#include "ui_registrar.h"
#include"menu.h"
REGISTRAR::REGISTRAR(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::REGISTRAR)
{
    ui->setupUi(this);
}

REGISTRAR::~REGISTRAR()
{
    delete ui;
}




void REGISTRAR::on_pushButton_menu_clicked()
{
    MENU menu;
    menu.setModal(true);
    menu.exec();
}

