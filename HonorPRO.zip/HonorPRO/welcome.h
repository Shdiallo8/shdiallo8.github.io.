
#ifndef WELCOME_H
#define WELCOME_H
#include "asap.h"



class Welcome
{
public:
    Welcome();
};

#endif // WELCOME_H
